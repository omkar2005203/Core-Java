
//Java Assignment - 3	
package OneToEight;
import java.util.Scanner;

public class Calculator {
public double add(int a , int b) {
	return a+b;
}

public double mul(int a , int b) {
	return a*b;
}

public double sub(int a , int b) {
	return a-b;
}


public double div(int a , int b) {
	return a/b;
}


//	public static void main(String[] args) {
//		
//		
//		
//		System.out.println("Enter num 1:");
//		Scanner s = new Scanner(System.in);
//		int a = s.nextInt();
//		
//		System.out.println("Enter num 2:");
//		Scanner e = new Scanner(System.in);
//		int b = e.nextInt();
//		
//		Calculator c = new Calculator();
//		
//		System.out.println("The sum of "+a+" and "+b+" is: "+c.add(a, b));
//		System.out.println("The mul of "+a+" and "+b+" is: "+c.mul(a, b));
//		System.out.println("The sub of "+a+" and "+b+" is: "+c.sub(a, b));
//		System.out.println("The divide of "+a+" and "+b+" is: "+c.div(a, b));
//		
//		
//		
//	}

}
